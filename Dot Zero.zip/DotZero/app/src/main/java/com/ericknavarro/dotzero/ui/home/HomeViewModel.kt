package com.ericknavarro.dotzero.ui.home

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import com.ericknavarro.dotzero.R
import com.ericknavarro.dotzero.models.Note
import java.util.*
import kotlin.collections.ArrayList

class HomeViewModel : ViewModel() {

    /*private val users: MutableLiveData<List<Note>> by lazy {
        MutableLiveData<List<Note>>().also {
            getNotesList()
        }
    }

    fun getUsers(): LiveData<List<User>> {
        return users
    }

    private fun loadUsers() {
        // Do an asynchronous operation to fetch users.
    }*/

    fun getNotesList() : MutableList<Note>{

        val notes: MutableList<Note> = ArrayList()

        notes.add(Note(1, "hola", "hola", R.color.colorPrimaryDark, Date(), 1, 0))
        notes.add(Note(2, "Baah", "hola", R.color.colorAccent, Date(), 1, 0))
        notes.add(Note(2, "Baah", "hola", R.color.colorAccent, Date(), 1, 0))
        notes.add(Note(2, "Baah", "hola", R.color.colorAccent, Date(), 1, 0))
        notes.add(Note(2, "Baah", "hola", R.color.colorAccent, Date(), 1, 0))
        notes.add(Note(2, "Baah", "hola", R.color.colorAccent, Date(), 1, 0))

        return notes

    }

}
