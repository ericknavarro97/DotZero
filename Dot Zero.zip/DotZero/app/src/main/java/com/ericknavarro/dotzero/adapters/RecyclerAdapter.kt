package com.ericknavarro.dotzero.adapters

import android.arch.lifecycle.LiveData
import android.content.Context
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

import com.ericknavarro.dotzero.R
import com.ericknavarro.dotzero.models.Note

class RecyclerAdapter : RecyclerView.Adapter<RecyclerAdapter.ViewHolder>() {

    var notes: MutableList<Note>  = ArrayList()
    lateinit var context:Context

    fun RecyclerAdapter(notes: MutableList<Note>, context: Context){
        this.notes = notes
        this.context = context
    }


    fun removeAt(position: Int) {
        notes.removeAt(position)
        notifyItemRemoved(position)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = notes[position]

        holder.bind(item, context)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return ViewHolder(layoutInflater.inflate(R.layout.adapter_note, parent, false))
    }

    override fun getItemCount() = notes.size

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val titleNote = view.findViewById(R.id.titleNote) as TextView
        private val colorNote = view.findViewById(R.id.LinearLayoutColor) as LinearLayout
        private val noteList = view.findViewById(R.id.LinearLayoutNote) as LinearLayout

        fun bind(note: Note, context: Context){

            titleNote.text = note.title
            colorNote.setBackgroundColor(note.color)

            noteList.setOnClickListener { Toast.makeText(context,"id: " + note.id, Toast.LENGTH_SHORT).show() }

        }

    }

}