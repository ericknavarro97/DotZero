package com.ericknavarro.dotzero.models

import java.util.*

data class Note(
    var id: Long,
    var title: String,
    var body: String,
    var color: Int,
    var lastUpdated: Date,
    var isArchived: Byte = 1,
    var isDeleted: Byte = 0
)

