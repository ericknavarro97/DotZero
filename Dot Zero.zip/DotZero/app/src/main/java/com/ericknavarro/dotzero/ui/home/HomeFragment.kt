package com.ericknavarro.dotzero.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.support.v4.app.Fragment
import android.arch.lifecycle.ViewModelProviders
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.helper.ItemTouchHelper
import android.widget.SimpleAdapter
import com.ericknavarro.dotzero.R
import com.ericknavarro.dotzero.SwipeToArchiveCallback
import com.ericknavarro.dotzero.adapters.RecyclerAdapter

class HomeFragment : Fragment() {

    private lateinit var homeViewModel: HomeViewModel

    private lateinit var mRecyclerView : RecyclerView
    private val mAdapter : RecyclerAdapter = RecyclerAdapter()

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        homeViewModel = ViewModelProviders.of(this).get(HomeViewModel::class.java)

        val root = inflater.inflate(R.layout.fragment_home, container, false)

        setUpRecyclerView(root)

        val swipeHandler = object : SwipeToArchiveCallback(root.context) {
            override fun onSwiped(p0: RecyclerView.ViewHolder, p1: Int) {
                mAdapter.removeAt(p0.adapterPosition)
            }
        }

        val itemTouchHelper = ItemTouchHelper(swipeHandler)
        itemTouchHelper.attachToRecyclerView(mRecyclerView)

        return root
    }

    /**
     * <p>SetUp the recycler view</p>
     *
     * @param root View of notes fragment
     */
    private fun setUpRecyclerView(root: View){
        mRecyclerView = root.findViewById(R.id.recyclerNotes) as RecyclerView
        mRecyclerView.setHasFixedSize(true)
        mRecyclerView.layoutManager = LinearLayoutManager(root.context)
        mAdapter.RecyclerAdapter(HomeViewModel().getNotesList(), root.context)
        mRecyclerView.adapter = mAdapter
    }



}
